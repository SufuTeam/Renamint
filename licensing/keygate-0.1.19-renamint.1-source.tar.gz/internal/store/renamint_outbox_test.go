package store_test

import (
    "context"
    "testing"
    "github.com/google/uuid"
    "github.com/tabloy/keygate/internal/model"
)

func TestRenamintPurchaseOutboxAtomicity(t *testing.T) {
    s := setupTestDB(t)
    defer s.Close()
    ctx := context.Background()
    seed := activationLicense(t, s, ctx, 2)
    plan, err := s.FindPlanByID(ctx, seed.PlanID)
    if err != nil { t.Fatal(err) }
    fresh := func() *model.License {
        return &model.License{ID:uuid.NewString(), ProductID:seed.ProductID, PlanID:seed.PlanID, Email:"outbox@example.test", LicenseKey:"QA-"+uuid.NewString(), Status:"active", StripeCheckoutSessionID:"cs_test_"+uuid.NewString()}
    }
    count := func(table, id string) int {
        var n int
        if err := s.DB.NewRaw("SELECT count(*) FROM "+table+" WHERE id = ?",id).Scan(ctx,&n); err != nil { t.Fatal(err) }
        return n
    }
    t.Run("commit both exactly once",func(t *testing.T) {
        lic:=fresh()
        if err:=s.CreateLicenseWithSubscriptionAndEmail(ctx,lic,plan,"QA license",lic.LicenseKey);err!=nil {t.Fatal(err)}
        if count("licenses",lic.ID)!=1 || count("email_queue",lic.ID)!=1 {t.Fatal("license and email did not commit together")}
        if err:=s.CreateLicenseWithSubscriptionAndEmail(ctx,lic,plan,"QA license",lic.LicenseKey);err==nil {t.Fatal("duplicate purchase inserted")}
        if count("email_queue",lic.ID)!=1 {t.Fatal("duplicate email")}
    })
    t.Run("queue failure rolls back license",func(t *testing.T) {
        lic:=fresh()
        if _,err:=s.DB.NewRaw("INSERT INTO email_queue(id,to_addr,subject,body) VALUES (?, ?, ?, ?)",lic.ID,lic.Email,"collision","test").Exec(ctx);err!=nil {t.Fatal(err)}
        if err:=s.CreateLicenseWithSubscriptionAndEmail(ctx,lic,plan,"QA license",lic.LicenseKey);err==nil {t.Fatal("expected queue collision")}
        if count("licenses",lic.ID)!=0 {t.Fatal("license survived queue failure")}
    })
    t.Run("license conflict rolls back queue",func(t *testing.T) {
        first:=fresh()
        if err:=s.CreateLicenseWithSubscriptionAndEmail(ctx,first,plan,"QA license",first.LicenseKey);err!=nil {t.Fatal(err)}
        second:=fresh();second.StripeCheckoutSessionID=first.StripeCheckoutSessionID
        if err:=s.CreateLicenseWithSubscriptionAndEmail(ctx,second,plan,"QA license",second.LicenseKey);err==nil {t.Fatal("duplicate session accepted")}
        if count("email_queue",second.ID)!=0 || count("licenses",second.ID)!=0 {t.Fatal("partial transaction survived")}
    })
}
