# Renamint Keygate 0.1.19-renamint.2

Upstream: 6e0e7a784bf6dd93cecbb0fff8f82c0b10954078 (v0.1.19).

Changes: atomic paid-license and email-queue creation; durable full-refund markers serialized with initial issuance, including reversed webhook ordering; checkout verification refuses reversed payments. Subscription, renewal and partial-refund policy stays upstream.

Build: docker buildx build --platform linux/amd64 -f Dockerfile.renamint --load -t renamint-keygate:0.1.19-payments2 .
Test with a dedicated PostgreSQL database: TEST_DATABASE_URL=... go test ./internal/store ./internal/payment -run Renamint -count=1

The unchanged frontend is supplied by the pinned upstream runtime image. Its full source and dependency lockfile are included under web/.
