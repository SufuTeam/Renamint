package payment

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"sync"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/google/uuid"
	"github.com/stripe/stripe-go/v82"
	"github.com/tabloy/keygate/internal/model"
	"github.com/tabloy/keygate/internal/store"
)

// Exercises the actual database and both webhook handlers in each delivery
// order. In particular, a refund must not be forgotten before a license exists.
func TestRenamintRefundDeliveryOrder(t *testing.T) {
	dsn := os.Getenv("TEST_DATABASE_URL")
	if dsn == "" {
		t.Fatal("TEST_DATABASE_URL is required for this integration test")
	}
	s, err := store.New(dsn)
	if err != nil {
		t.Fatal(err)
	}
	defer s.Close()
	if err := s.RunMigrations("../../db/migrations"); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	oldKey := stripe.Key
	stripe.Key = ""
	defer func() { stripe.Key = oldKey }()
	product := &model.Product{Name: "Refund ordering", Slug: "refund-order-" + uuid.NewString(), Type: "desktop"}
	if err := s.CreateProduct(ctx, product); err != nil {
		t.Fatal(err)
	}
	plan := &model.Plan{ProductID: product.ID, Name: "Lifetime", Slug: "lifetime", LicenseType: "perpetual", LicenseModel: "standard"}
	if err := s.CreatePlan(ctx, plan); err != nil {
		t.Fatal(err)
	}
	h := &StripeHandler{Store: s}
	for _, scenario := range []string{"refund first", "payment first", "concurrent", "partial refund first"} {
		t.Run(scenario, func(t *testing.T) {
			id := uuid.NewString()
			pi, sid, email := "pi_test_"+id, "cs_test_"+id, "refund-"+id+"@example.test"
			paid, _ := json.Marshal(map[string]any{"id": sid, "customer_email": email, "payment_intent": pi, "payment_status": "paid", "mode": "payment", "metadata": map[string]string{"plan_id": plan.ID, "product_id": product.ID, "license_type": "perpetual", "updates_days": "0"}})
			full := scenario != "partial refund first"
			amount := 1990
			if !full {
				amount = 100
			}
			refund, _ := json.Marshal(map[string]any{"id": "ch_test_" + id, "payment_intent": pi, "refunded": full, "amount_refunded": amount})
			pay := func() error { return h.onCheckoutCompleted(ctx, paid) }
			revoke := func() error { return h.onChargeRefunded(ctx, refund) }
			if scenario == "concurrent" {
				var wg sync.WaitGroup
				start := make(chan struct{})
				errs := make(chan error, 2)
				for _, action := range []func() error{pay, revoke} {
					wg.Add(1)
					go func(action func() error) { defer wg.Done(); <-start; errs <- action() }(action)
				}
				close(start)
				wg.Wait()
				close(errs)
				for err := range errs {
					if err != nil {
						t.Fatal(err)
					}
				}
			} else {
				actions := []func() error{revoke, pay}
				if scenario == "payment first" {
					actions = []func() error{pay, revoke}
				}
				for _, action := range actions {
					if err := action(); err != nil {
						t.Fatal(err)
					}
				}
			}
			// A later duplicate completion must not resurrect a reversed order.
			if err := pay(); err != nil {
				t.Fatal(err)
			}
			licenses, err := s.ListLicensesByEmail(ctx, email)
			if err != nil {
				t.Fatal(err)
			}
			if scenario == "partial refund first" {
				if len(licenses) != 1 || licenses[0].Status != model.StatusActive {
					t.Fatal("partial refund incorrectly blocked the license")
				}
				return
			}
			for _, license := range licenses {
				if license.Status != model.StatusRevoked {
					t.Fatalf("fully refunded order left an active license: %s", scenario)
				}
			}
			if scenario == "refund first" {
				var queued int
				if err := s.DB.NewRaw("SELECT count(*) FROM email_queue WHERE to_addr = ?", email).Scan(ctx, &queued); err != nil {
					t.Fatal(err)
				}
				if len(licenses) != 0 || queued != 0 {
					t.Fatal(fmt.Sprintf("refunded order issued %d licenses and %d emails", len(licenses), queued))
				}
				stubStripe(t, func(w http.ResponseWriter, r *http.Request) {
					if r.Method != http.MethodGet || r.URL.Path != "/v1/checkout/sessions/"+sid {
						t.Errorf("unexpected Stripe request: %s", r.URL.Path)
						http.Error(w, "unexpected request", http.StatusNotFound)
						return
					}
					w.Header().Set("Content-Type", "application/json")
					_, _ = w.Write(paid)
				})
				recorder := httptest.NewRecorder()
				c, _ := gin.CreateTestContext(recorder)
				c.Request = httptest.NewRequest(http.MethodGet, "/api/v1/checkout/verify?session_id="+sid, nil)
				h.VerifyCheckoutSession(c)
				if recorder.Code != http.StatusGone || !strings.Contains(recorder.Body.String(), "PAYMENT_REVERSED") {
					t.Fatalf("reversed checkout was presented as successful: %d %s", recorder.Code, recorder.Body.String())
				}
			}
		})
	}
}
