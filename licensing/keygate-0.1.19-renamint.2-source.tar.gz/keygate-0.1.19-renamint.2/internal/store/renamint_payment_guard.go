package store

import (
	"context"
	"errors"

	"github.com/uptrace/bun"
)

const stripePaymentTakenBackProvider = "renamint_stripe_full_takeback"

var ErrPaymentTakenBack = errors.New("payment has been fully taken back")

// Both the durable takeback marker and initial paid-license insertion use this
// transaction lock. A refund either observes the committed license or prevents
// it from being created. The marker deliberately survives webhook retries.
func lockStripePaymentIn(ctx context.Context, tx bun.Tx, paymentIntent string) error {
	_, err := tx.ExecContext(ctx, "SELECT pg_advisory_xact_lock(hashtextextended(?, 0))", "renamint:payment:"+paymentIntent)
	return err
}

func (s *Store) RecordStripePaymentTakenBack(ctx context.Context, paymentIntent string) error {
	if paymentIntent == "" {
		return nil
	}
	return s.RunInTx(ctx, func(ctx context.Context, tx bun.Tx) error {
		if err := lockStripePaymentIn(ctx, tx, paymentIntent); err != nil {
			return err
		}
		_, err := ClaimProcessedEventIn(ctx, tx, stripePaymentTakenBackProvider, paymentIntent)
		return err
	})
}

func (s *Store) StripePaymentTakenBack(ctx context.Context, paymentIntent string) (bool, error) {
	if paymentIntent == "" {
		return false, nil
	}
	return HasProcessedEventIn(ctx, s.DB, stripePaymentTakenBackProvider, paymentIntent)
}

func guardStripePaymentIn(ctx context.Context, tx bun.Tx, paymentIntent string) error {
	if err := lockStripePaymentIn(ctx, tx, paymentIntent); err != nil {
		return err
	}
	reversed, err := HasProcessedEventIn(ctx, tx, stripePaymentTakenBackProvider, paymentIntent)
	if err != nil {
		return err
	}
	if reversed {
		return ErrPaymentTakenBack
	}
	return nil
}
